# example v1.0

__version__ = "1.0"

def example_version():
    return __version__
