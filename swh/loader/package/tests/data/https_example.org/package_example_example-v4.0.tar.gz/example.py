# example v4.0

__version__ = "4.0"

def example_version():
    return __version__
