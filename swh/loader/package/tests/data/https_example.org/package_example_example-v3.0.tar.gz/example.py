# example v3.0

__version__ = "3.0"

def example_version():
    return __version__
