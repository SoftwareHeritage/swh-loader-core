# example v2.0

__version__ = "2.0"

def example_version():
    return __version__
