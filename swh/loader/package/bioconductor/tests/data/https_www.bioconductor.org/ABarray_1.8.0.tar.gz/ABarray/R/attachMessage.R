.First.lib = function(libname, pkgname) {
  cat("\n\nWelcome to Applied Biosystems AB1700\n",
      "    This package performs analysis for AB1700\n",
      "    gene expression data\n")
}
