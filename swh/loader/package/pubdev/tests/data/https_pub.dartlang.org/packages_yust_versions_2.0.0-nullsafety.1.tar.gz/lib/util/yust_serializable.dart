abstract class YustSerializable {
  dynamic toJson();
}
