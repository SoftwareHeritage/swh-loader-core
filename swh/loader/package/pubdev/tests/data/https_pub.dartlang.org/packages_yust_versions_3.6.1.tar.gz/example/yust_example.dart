void main() {
  // var awesome = Awesome();
  // print('awesome: ${awesome.isAwesome}');
}
