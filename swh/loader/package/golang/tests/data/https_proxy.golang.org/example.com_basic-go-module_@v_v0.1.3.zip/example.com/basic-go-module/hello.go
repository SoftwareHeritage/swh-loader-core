package hello

func Hello() string {
    return "Hello, world."
}

