#![feature(plugin)]
#![plugin(clippy)]
#![deny(clippy)]

fn core() {}

fn main() {
    core();
}
