// error-pattern: `conf_file` must be a named value

#![feature(plugin)]
#![plugin(clippy(conf_file))]

fn main() {}
