<!--
Hi there! Whether you've come to make a suggestion for a new lint, an improvement to an existing lint or to report a bug or a false positive in Clippy, you've come to the right place.

If you want to report that Clippy does not compile, please be sure to be using the *latest version* of *Rust nightly*! Compiler plugins are highly unstable and will only work with a nightly Rust for now. If you are but still have a problem, please let us now!

Thank you for using Clippy!

Write your comment below this line: -->
