#![feature(plugin)]
#![plugin(clippy)]
#![deny(clippy)]

use std::*;

fn main() { }
