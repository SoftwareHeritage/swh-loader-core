#![feature(plugin)]
#![plugin(clippy(conf_file="./tests/auxiliary/conf_whitelisted.toml"))]

fn main() {}
